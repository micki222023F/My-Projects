const double M_TO_I = 39.37007874;
const double M_TO_F = 3.280839895;
const double M_TO_Y = 1.0936132983;

const double I_TO_M = 0.0254;
const double F_TO_M = 0.3048;
const double Y_TO_M = 0.9144;

//WEIGHT
const double G_TO_O = 0.0352739907;
const double G_TO_P = 0.0022046244;
const double G_TO_T = 0.0000011023;

const double O_TO_G = 28.3495;
const double P_TO_G = 453.592;
const double T_TO_G = 907184;
